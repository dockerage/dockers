#!/bin/sh
autoreconf --force --install
rm -rf autom4te.cache/
